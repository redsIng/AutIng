function parsedCoord = stateParser(coord, mode)
%% Parsing of State's coordinates
parsedCoord = [];
switch mode
    case "double"
        % Converts Matlab Griwdorld's state (string) to double array
        parsedCoord = regexp(coord,'\d*','Match');
        parsedCoord = str2double(parsedCoord);
    case "string"
        % Converts double array of GW's state into string format
        parsedCoord = "["+num2str(coord(1))+","+num2str(coord(2))+"]";
end
