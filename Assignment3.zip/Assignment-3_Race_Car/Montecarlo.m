classdef Montecarlo < handle
    properties
        % Policy
        Pi
        % Environment Object
        Env
        % Agent Object
        Agent
        % Quality Function
        Q
        % C Matrix
        C
        % Epsilon
        Eps
        % Gamma
        gamma
        % time step
        T
        % Episode Cell
        EpisodeCell
    end
  
    methods
        % Initialize, for all s ∈ S, a ∈ A(s):
        %   Q(s, a) ← arbitrary
        %   N(s, a) ← 0
        %   Pi(s) ← argmax_a Q(s, a)
        function obj = Montecarlo(Env, Agent, epsilon,gamma)
            % get environment object
            obj.Env = Env;
            % get agent object
            obj.Agent = Agent;
            % Importance parameter Gamma
            obj.gamma = gamma;
            % initialize quality function at zero (m*n,9)
            obj.Q = zeros(obj.Env.GW.GridSize(1)*obj.Env.GW.GridSize(2), ...
                length(obj.Agent.A));
            % C matrix
            obj.C = zeros(obj.Env.GW.GridSize(1)*obj.Env.GW.GridSize(2), ...
                length(obj.Agent.A));
            % TODO: Q arbitrario non nullo
            % initialize policy at random
            obj.Pi = randi([1,9],...
                obj.Env.GW.GridSize(1)*obj.Env.GW.GridSize(2),1);
            % TODO: Pi come argmax
            obj.Eps = epsilon;
            % init Episode Cell
            obj.EpisodeCell = cell(0,3);
        end
        function [action, bool] = epsGreedy(obj, policy)
            % select the action with e-greedy concept
            
            % evaluate possible actions
            actionSpace = obj.Agent.possibleActions();
            % evaluate prob
            prob = rand();
            % get state index
            idxS = sub2ind(obj.Env.GW.GridSize, obj.Agent.S(1), obj.Agent.S(2));
            % condition
            cond = find(ismember(actionSpace, policy(idxS)), 1);
            if prob > obj.Eps && ~isempty(cond)
                %                 [~, argMax] = max(obj.Q(idxS,actionSpace));
                %                 action = policy(argMax);
                action = policy(idxS);
                
            elseif ~isempty(actionSpace)
                action = actionSpace(randi(length(actionSpace)));
                %             else
                %                 action = find(obj.
            else
                action = NaN;
            end
            
            % TODO: implement decrescent epsilon value
        end
        function control(obj)
            % Performs MC control using episode list
            % [ S0 , A0 , R1, . . . , ST −1 , AT −1, RT , ST ]
            %   G ← 0
            %   W ← 1
            %   For t = T − 1, T − 2, . . . down to 0:
            %       G ← γ*G + R_t+1
            %       N(St, At ) ← N(St,At ) + W
            %       Q(St, At ) ← Q(St,At) + (W/N(St,At))*[G − Q(St,At )]
            %       Pi(St) ← argmax_a Q(St,a)
            %       If At != Pi(St) then exit For loop
            %           W ← W * Pi(At|St)/b(At|St))
            
            % Reset Environment
            state = obj.Env.resetEnv();
            % Define first reward for while-loop
            rew = -1;
            % Create new episode
            while ~isnan(rew)
                % Identify current action for current state
                act = obj.epsGreedy(obj.Pi);
                if isnan(act)
                    state=obj.Env.resetEnv();
                    act = obj.epsGreedy(obj.Pi);
                    action = actionParser(act, 'action');
                else
                    action = actionParser(act, 'action');
                end
                [state, rew] = obj.Env.step(state, action);
                
            end
            episodeArray = obj.Env.Episode.values;
            %Storing entire episode
            obj.EpisodeCell(end+1,:)=episodeArray;
            episodeActions = episodeArray{1};
            episodeReward = episodeArray{2};
            episodeStates = episodeArray{3};
            episodeLength=length(episodeArray{1});
            G=0;
            W=1;
            Time=episodeLength;
            for t=Time-1:-1:1
                G= episodeReward(t)+obj.gamma*G;
                St = episodeStates(t,:);
                % get state index
                idxS = sub2ind(obj.Env.GW.GridSize, St(1), St(2));
                At = actionParser(episodeActions(t,:),'policy');
                obj.C(idxS,At) = obj.C(idxS,At)+W;
                obj.Q(idxS,At) = obj.Q(idxS,At)+(W*(G-obj.Q(idxS,At)))/(obj.C(idxS,At));
%                 [~,newPolicy]= max(obj.Q(idxS,:));
                Astar = find(obj.Q(idxS,:)==max(obj.Q(idxS,:)),1,'first');
                obj.Pi(idxS) = Astar;
                
            end
%             sprintf("Numero Passi: %d", Time);
        end
    end
end
