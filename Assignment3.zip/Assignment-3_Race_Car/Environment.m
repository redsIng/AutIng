classdef Environment < handle
    properties
        % MATLAB Reinforcement Learning Environment
        Env
        % Gridworld Object
        GW
        % Start Vector
        StartVect
        % Action Vector: speed
        V
        % Maximum Speed
        MaxSpeed
        % Obstacles
        Obstacles
        % Finish Line
        FinishLine
        % Episode
        Episode
    end
    methods
        function obj = Environment(M, N, startLineLen, finishLineLen)
            obj.GW = createGridWorld(M, N);
            obj.Env = rlMDPEnv(obj.GW);
            obj.StartVect = createObstacles(obj.Env, finishLineLen, startLineLen);
            obj.V = [0 0];
            obj.MaxSpeed = 1:5;
            obj.GW.R = -ones(size(obj.GW.R));
            obj.Obstacles = getTerminals(obj.GW.ObstacleStates);
            obj.FinishLine = getTerminals(obj.GW.TerminalStates);
%             obj.Episode = containers.Map({'S','A','R'},...
%                 {[stateParser(obj.GW.CurrentState,'double')],...
%                 [0, 0],[0]},'UniformValues',false);
            obj.Episode = containers.Map({'S','A','R'},{[],[],[]},'UniformValues',false);

        end
        function state = getState(obj)
            state = [stateParser(obj.GW.CurrentState,'double'),...
                obj.V];
        end
        function sp = resetEnv(obj)
            obj.GW.CurrentState = obj.StartVect(randi(length(obj.StartVect)));
            obj.V = [0 0];
            sp = [[stateParser(obj.GW.CurrentState,'double')], obj.V];
        end
        function resetEp(obj)
            obj.Episode = containers.Map({'S','A','R'},{[],[],[]},'UniformValues',false);

        end
        function show(obj)
            plot(obj.Env)
        end
        function sp = nextState(obj, state, action)
            % Apply the selected action to given state and returns the next
            % state. We assume to move with current speed and then apply
            % its change.
            
            % initialize next state vector
            sp = state;
            % apply action and evaluate next state
            % with controls to prevent exit from boundaries
            sp(1) = max(state(1) - state(3), 1);   % - because the agent starts at bottom
            sp(2) = min(state(2) + state(4), obj.GW.GridSize(2));
            sp(3) = state(3) + action(1);
            sp(4) = state(4) + action(2);
        end
        
        function [sp, reward] = step(obj, state, action)
            % Returns the reward and new state when action is taken on state
            % Checks the following 2 cases maintaining the order:
            %   1. car finishes race by crossing the finish line
            %   2. car goes out of track
            
            % Defines reward
            reward = -1;
            % Detects if finish line is crossed.
            if isTerminal(obj.FinishLine, state)   % finish line crossed
                % If true, updateEpisode the next-state/action/reward triple to
                % the episode and return.
                reward = NaN;
                sp=state;
                obj.GW.CurrentState = stateParser(sp(1:2),'string');
%                 disp("Episode Terminated");
                return
            elseif isTerminal(obj.Obstacles, state)    % obstacles hitted
                % If true, bring back the agent to start but don't
                % reinitialize the episode to add negative rewards
                sp = obj.resetEnv();
            else
                sp = nextState(obj, state, action);

            end
            updateEpisode(obj, sp(1:2), action, reward);
            obj.V = sp(3:4);
            obj.GW.CurrentState = stateParser(sp(1:2),'string');
%             pause()
        end
        function updateEpisode(obj, state, action, reward)
            
            % utility function to updateEpisode the next state to the episode
            obj.Episode('S') = [obj.Episode('S');state];
            obj.Episode('A') = [obj.Episode('A');action];
            obj.Episode('R') = [obj.Episode('R');reward];
             
        end
    end
end
