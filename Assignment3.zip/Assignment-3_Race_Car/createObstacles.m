function startVect = createObstacles(env, finishLineLen, startLineLen)
%% Create Obstacles in the given map as a curve to the right.
grid = env.Model;
gridSize = grid.GridSize;
M = gridSize(1);
N = gridSize(2);
obstaclesStates = strings(0,1);
leftStart = 3;
a = (M-1)/N^2;
% Terminal States
finishLine = finishLineLen;
terminalVect = strings(finishLine,1);
for i = 1:finishLine
   terminalVect(i,:)= "["+num2str(i+1)+","+num2str(N)+"]";
end
grid.TerminalStates = terminalVect;
% Left Curve
rightMargins = [];
for y = 1:M
    x = fix(sqrt(y/a));
    epsilon = randi([-2,1]);
    if y == 1
        rightEnd = N;
        rightMargins(1,1) = rightEnd;
    else
        rightEnd = max(N-x+epsilon, leftStart+epsilon);
        rightMargins(end+1,1) = rightEnd;
    end
    for ii = 1:rightEnd
        obstaclesStates(end+1,:)= "["+num2str(y)+","+num2str(ii)+"]";
    end
end
% Right Curve
termStatesNum = length(grid.TerminalStates);
startStatesNum = randi([rightMargins(end)+startLineLen-1, termStatesNum]);
a = (M-termStatesNum-1)/(N-rightMargins(end)-startStatesNum)^2;
for y = termStatesNum+2:M
    x = fix(sqrt((y-termStatesNum-1)/a));
    epsilon = randi([-2,1]);
    leftEnd = max(N-x+epsilon, N-rightMargins(y)-x+epsilon);
% leftEnd = N-x;
    for ii = leftEnd:N
        obstaclesStates(end+1,:)= "["+num2str(y)+","+num2str(ii)+"]";
    end
end
% evaluate the start line 
leftMarginStart = rightMargins(end)+1;
rightMarginStart = leftEnd-1;
startVect = strings(0,1);
for si = leftMarginStart:rightMarginStart
    startVect(end+1,1) = "["+num2str(M)+","+num2str(si)+"]";
end
grid.ObstacleStates  = obstaclesStates;
updateStateTranstionForObstacles(grid)
grid.CurrentState = startVect(randi(length(startVect)));
end