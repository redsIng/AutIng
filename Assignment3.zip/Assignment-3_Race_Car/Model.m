clc
clear
close all
%% GridWorld Model
% Rappresentano le 4 azioni per aumentare o diminuire la velocità:
% -N : aumento velocità verticalmente
% -S : diminuisco velocità verticalmente
% -E : aumento velocità orizzontalmente
% -W : diminuisco velocità orizzontalmente
% m:= caselle verticalmente
% n:= caselle orizzontalmente
% k:= azioni
m=50;
n=35;
finishLineLen = 8;
startLineLen = 5;
GW = createGridWorld(m,n);
env = rlMDPEnv(GW);
startVect = createObstacles(env, finishLineLen, startLineLen);
GW.R = -ones(size(GW.R));
plot(env)
%% Costanti di simulazione
% Numero di episodi
numEpisodes = 1e3;
% Numero di iterazioni
numRepetions = 1e3;
% Fattore di Sconto
gamma = 1;
% Vettore di azioni
A = ['N';'S';'E';'W'];
% Vettore di azioni di partenza
A_start = ['N';'E';'W'];
% Numero di stati
S = (m*n)^2*length(A);
% Policy di azioni
policy = randi([-1,1],S,2);
% Velocità massima della macchina
vel = 1:5;
% Matrici N e Q
N = zeros(S,length(A));
Q = zeros(S,length(A));
%% Simulate Race as MonteCarlo mdp
for t = 1:numRepetions
    for e = 1:numEpisodes
        % Parsing the state from string to double and select random start
        % state
        s0 = stateParser(startVect(randi(length(startVect))),"double");
        % Chose random velocity to start, avoiding sud
        v0 = vel(randi(length(A_start),1,3));
        % recreate v0 with all coordinates
        v0 = horzcat([v0(1),0],v0(2:3));
        % Chose random action, avoiding sud
        d0 = A_start(randi(length(A_start)));        
        % Find state number as double from given coordinates and action
        s0 = sub2ind(size(GW.T), s0(1), s0(2), find(ismember(A_start,d)));
        % Evaluate current episode state transition
        [s, a, r] = nextState(s0, d0, policy);        
         G = 0;
        for t = length(s)-1: -1: 1
            G = r(t) + gamma*G;
            N(s(t),a(t)) = N(s(t),a(t)) + 1;
            Q(s(t),a(t)) = Q(s(t),a(t)) + 1/N(s(t),a(t))*(G - Q(s(t),a(t)));
        end
    end
    for s = 1:S
        policy(s) = find(Q(s,:) == max(Q(s,:)), 1, 'first');
    end
end
