function [sp, r] = move(s, a, GW)
%% Evaluate Next State
% s: current agent's state, as double
% GW: gridworld
%% Variables
% T: transition matrix 
T = GW.T;
% R: reward matrix
R = GW.R;
% Map current state into coordinates
sizeT = size(T);
[x, y, d] = ind2sub(sizeT, s);
% Parse coordinate into string
parsedState = stateParser([x,y], "string");
% checks if current state is an obstacle
isObs = find(ismember(GW.ObstacleStates, parsedState));

switch isObs
    case 0  % current state isn't an obstacle
    % move the agent to selected direction with specified velocity
    
end


