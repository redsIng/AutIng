function terminalStates = getTerminals(stateList)
% Make a copy of terminal states for utlity
terminalStates = zeros(length(stateList), 2);
for i = 1:size(terminalStates,1)
    terminalStates(i,:) = stateParser(stateList(i), 'double');
end
end