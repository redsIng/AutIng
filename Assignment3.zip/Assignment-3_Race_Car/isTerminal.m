function bool = isTerminal(terminalStates, currentState)
% Detects if the Agent is in a possible terminal state
cond = find(ismember(terminalStates, currentState(1:2), 'rows'), 1);
if ~isempty(cond)
    bool = true;
else
    bool = false;
end
end