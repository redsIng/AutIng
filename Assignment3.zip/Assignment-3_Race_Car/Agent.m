classdef Agent < handle
    properties
        % State <- [x, y, v_x, v_y]
        S
        % Action Space
        A
        % Reward
        R
        % Environment
        Env
        
    end
    methods
        function obj = Agent(Env)
            obj.Env = Env;
            obj.S = [stateParser(obj.Env.GW.CurrentState,'double'), [0 0]];
            obj.A = [-1, -1; -1, 0; 0, -1; -1, 1;...
                0, 0; 1, -1; 0, 1; 1, 0; 1, 1];
            obj.R = [];
        end
        function reset(obj)
            % reset agent's state
            obj.S = obj.Env.StartVect(...
                randi(length(obj.Env.StartVect)));
            obj.S = [stateParser(obj.S,'double'), [0 0]];
        end
        function [ax,ay] = increments(obj,s,sp)
            % increments defines the direction in which to draw the
            % collision region along
            ay = 0;
            ax = 0;
            if s(1) > sp(1)
                ax = -1;
            elseif s(1) <= sp(1)
                ax = 1;
            end
            if s(2) > sp(2)
                ay = -1;
            elseif s(2) <= sp(2)
                ay = 1;
            end
        end
        
        function bool = obstacleCheck(obj,newVel)
            %Evaluate the presence of obstacles between state and nextState
            %to avoid illegal moves
            %Get currenst state
            state = obj.S(1:2);
            %Get obstacles List
            obstacleList = obj.Env.Obstacles;
            gridSize = obj.Env.GW.GridSize;
            %Get next state
            sp = [state(1)-newVel(1),state(2)+newVel(2)];
            if ~isempty(find(ismember(obstacleList,sp,'rows'), 1))...
                    ||~isempty(find(ismember(obstacleList,state,'rows'), 1))...
                    || sp(2)>gridSize(2)|| sp(2)<=1 || sp(1)>gridSize(1)|| sp(1)<=1
                    
                bool = false;
                return
            else
                %Che
                dx = abs(state(1)-sp(1));
                dy = abs(state(2)-sp(2));
                [ax,ay] = obj.increments(state, sp);
                %Define all state between state and next state
                collideRegion = [];
                for i = state(1):ax:sp(1)
                    for j= state(2):ay:sp(2)
                        collideRegion(end+1,:) = [i,j];
                    end
                end
                collideRegion(ismember(collideRegion,state,'rows'),:)=[];
                collideRegion(ismember(collideRegion,sp,'rows'),:)=[];
                
                % The collideRegion is empty -> there are no state between
                % state and next state. It is possible to move->bool = 1
                if isempty(collideRegion)
                    bool = 1;
                    return
                else
                    % Check horizonal and vertical case. If there are
                    % obstacles between state and next state, obstacleCheck fails.
                    %The move is illegal.
                    if state(1) == sp(1) || state(2) == sp(2)
                        for i = 1:size(collideRegion,1)
                            if ~isempty(find(ismember(obstacleList,collideRegion(i,:),'rows'), 1))
                                bool = false;
                                return
                            end
                        end
                    elseif dx == dy
                        %block NxN case
                        mainDiag = [state(1)+ax:ax:sp(1)-ax;state(2)+ay:ay:sp(2)-ay].';
                        %if mainDiag is empty-> block 2x2->move is legal
                        if isempty(mainDiag)
                            bool = 1;
                            return
                        else
                            %if is not a block 2x2, check if over the diagonal
                            %that connects state and next state there are
                            %obstacles.
                            for i = 1:size(mainDiag,1)
                                if ~isempty(find(ismember(obstacleList,mainDiag(i,:),'rows'), 1))
                                    bool = false;
                                    return
                                end
                            end
                        end
                    else
                        %CollideRegion is a block MxN with M!=N
                        
                        %States to exclud on state
                        toexcludestart = (state(1)+ax:ax:sp(1)).';
                        tempStatesStart = zeros(length(toexcludestart),2);
                        tempStatesStart(:,2) = state(2);
                        tempStatesStart(:,1) = toexcludestart;
                        %States to exclude on next state
                        toexcludeend = (sp(1)-ax:-ax:state(1)).';
                        tempStatesEnd = zeros(length(toexcludeend),2);
                        tempStatesEnd(:,2) = sp(2);
                        tempStatesEnd(:,1) = toexcludeend;
                        %List of all state to exclude vertically
                        stateExcluded = [tempStatesStart;tempStatesEnd];
                        toexcludestart = (state(2)+ay:ay:sp(2)).';
                        tempStateStart = zeros(length(toexcludestart),2);
                        tempStateStart(:,1) = state(1);
                        tempStateStart(:,2) = toexcludestart;
                        toexcludeend = (sp(2)-ay:-ay:state(2)).';
                        tempStateEnd = zeros(length(toexcludeend),2);
                        tempStateEnd(:,1) = sp(1);
                        tempStateEnd(:,2) = toexcludeend;
                        %List of all state to exclude vertically
                        stateExcluded = unique([stateExcluded; tempStateStart;tempStateEnd],'rows');
                        
                        bool = evaluateCollideRegion(collideRegion,stateExcluded,obstacleList,dx,dy);
                        return
                    end
                end

            end
            bool = true;
        end
        
        function actionSpace = possibleActions(obj)
            % Evaluate the space of possible actions for the current state
            % The universe of actions is:
            %   [-1, -1; -1, 0; 0, -1; -1, 1;0, 0; 1, -1; 0, 1; 1, 0; 1, 1]
            % The constraits to filter the possible actions are:
            % 0 <= v_x < 5; 0 <= v_y < 5
            % To avoid time loss, we assume that v_x and v_y cannot be both
            % zero.
            obj.S = obj.Env.getState();
            % get current speed
            velocity = obj.S(3:4);
            % define action space
            actionSpace = zeros(9,1);
            for i = 1:length(obj.A)
                newVel = velocity+obj.A(i,:);
                if (newVel(1) >= 0) && (newVel(1) < 5) && ...
                        (newVel(2) >= 0) && (newVel(2) < 5) && ...
                        ~(newVel(1) == 0 && newVel(2) == 0)
                    if obstacleCheck(obj,newVel)
                        actionSpace(i,1) = i;
                    else
                        
                    end
                end
            end
            actionSpace = actionSpace(actionSpace~=0);
        end
        function action = getAction(obj, policy)
            idxS = sub2ind(obj.Env.GridSize, obj.S(1), obj.S(2));
            action = actionParser(policy(idxS), 'action');
        end
        %         function bool = obstacleCheck(obj, i)
        %             m = obj.S(1) + obj.A(i,1);
        %             n = obj.S(2) + obj.A(i,2);
        %             for ii = 1:abs(obj.S(1) - m)
        %                 for jj = 1:(obj.S(2) - n)
        %                     obst = [ii, jj]
        %                     disp(obst)
        %                 end
        %             end
        %         end
    end
end