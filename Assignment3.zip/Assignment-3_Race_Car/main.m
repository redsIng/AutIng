clc
clear
close all
%% Create Environment
M = 20; % num of rows
N = 15; % num of cols
finishLineLen = 8;  % len of finish line
startLineLen = 5; % lef of start line
env = Environment(M, N, startLineLen, finishLineLen);
env.show();
numIteration = 2.e5;
% pause();
%% Create Agent
agent = Agent(env);
%% Create Montecarlo Controller
epsilon = 1.e-1;    % for eps-greedy
gamma = 1;
mcc = Montecarlo(env, agent, epsilon,gamma);
%% Simulation
for i=1:numIteration
    mcc.control()
%     pause(0.001);
    env.resetEp()
    if mod(i,1000) == 0
        disp(i)
    end
end
%% Save montecarlo object for checks

Q=mcc.Q;
policy = mcc.Pi;
episodes =mcc.EpisodeCell(end,:);
epsilon = mcc.Eps;
gamma= mcc.gamma;
obstacles = mcc.Env.Obstacles;
finishLine = mcc.Env.FinishLine;
startVect = mcc.Env.StartVect;
save learnedPolicy M N Q policy episodes epsilon gamma obstacles finishLine startVect 

%% Simulate Learnend Policy
clc 
clear 
close all
load learnedPolicy
%%
env = Environment(M, N, length(startVect), length(finishLine));
env.Obstacles = obstacles;
env.GW.ObstacleStates = [];
for i = 1:size(obstacles,1)
        env.GW.ObstacleStates(end+1,:)= "["+num2str(obstacles(i,1))+","+num2str(obstacles(i,2))+"]";
end
env.show();
s =env.resetEnv();
reward = -1;
while ~isnan(reward)
    idxS = sub2ind(env.GW.GridSize, s(1), s(2));
    action = actionParser(policy(idxS),'action');
    [s,reward]=env.step(s,action);
   
    pause();
end
