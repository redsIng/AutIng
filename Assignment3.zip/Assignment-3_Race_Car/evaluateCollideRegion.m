function bool = evaluateCollideRegion(collideRegion,stateExcluded,obstacleList,dx,dy)
for i= 1:length(collideRegion)
    %Check if state in collide region has to be
    %excluded
    cond = find(ismember(stateExcluded,collideRegion(i,:),'rows'), 1);
    if isempty(cond)
        %check if state in collide regions it is an
        %obstacles
        cond = find(ismember(obstacleList,collideRegion(i,:),'rows'), 1);
        if ~isempty(cond)
            bool = false;
            return
        end
    elseif dx==1||dy==1
        %check if state in collide regions it is an
        %obstacles
        cond = find(ismember(obstacleList,stateExcluded(cond,:),'rows'), 1);
        if ~isempty(cond)
            bool = false;
            return
        end
        
    end
end
bool = true;
end