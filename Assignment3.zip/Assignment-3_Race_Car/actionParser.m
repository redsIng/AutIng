function parsedAction = actionParser(action, str)
% Parse given action into policy index or given policy into selected action

% Action Space
A = [-1, -1; -1, 0; 0, -1; -1, 1; 0, 0; 1, -1; 0, 1; 1, 0; 1, 1];
if strcmp(str, 'policy')
    % parse action vect (dV_x, dV_y) into policy index
    parsedAction = find(ismember(A, action,'rows'));
elseif strcmp(str, 'action')
    % parse policy index into velocity increment
    parsedAction = A(action,:);
end
end